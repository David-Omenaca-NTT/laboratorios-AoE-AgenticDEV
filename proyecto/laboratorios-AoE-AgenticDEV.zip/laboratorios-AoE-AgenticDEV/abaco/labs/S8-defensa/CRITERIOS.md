# Criterios de superacion de S8

Lo que comprueba `abaco check S8`. Cada criterio es verdadero o falso: si
alguno queda en rojo, la estacion no se sella.

El detalle mecanico esta en verificar.py y puedes leerlo. No es un examen
secreto: saber como se te mide es parte de aprender a medir. Lo que no puedes
es modificarlo, porque la ejecucion que sella es la del pipeline y toma el
verificador de la plantilla, no tu copia.

## Entregable de la estacion

Demo, cuaderno de decisiones, metricas y defensa oral ante el dueno funcional.

## Pistas disponibles

3 escalones: empujon, direccion y fragmento de solucion.
Cada apertura queda registrada. No penaliza la nota, informa al mentor.
