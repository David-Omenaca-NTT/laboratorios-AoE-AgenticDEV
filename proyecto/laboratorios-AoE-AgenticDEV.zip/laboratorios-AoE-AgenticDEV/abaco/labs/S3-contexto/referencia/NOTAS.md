# Solucion de referencia de S3

Se libera al sellar la estacion o al desbloquearla.

Comparala con la tuya: donde difieran y por que es la conversacion de la
daily siguiente.
